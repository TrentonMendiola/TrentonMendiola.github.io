// CS410ProjectOneTrenton.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <limits>
#include <string>
#include <vector>

//method to change customer choice
void ChangeCustomerChoice(std::vector<std::pair<std::string, int>>& clients, const int clientSelect, const int optionSelect) {
    //change second value at vector index point clientSelect to option select
    clients.at(clientSelect).second = optionSelect;
}

//method to check user permission
//added user vector to store usernames and passwords in system to improve authenticaion and reduce vulnerabilities related to improper user authentication including users gaining access to higher level authorization than they are supposed to have
bool CheckUserPermissionAccess(std::vector<std::pair<std::string, std::string>>& users, const std::string& username, const std::string& password)
{
    //loops through pair vector
    for (size_t i = 0; i < users.size(); ++i) {
        //checks for an entry when username and password are both equal to the username and password variables
        if (users[i].first == username && users[i].second == password) {
            //if true return true allow user to log in
            return true;
        }
        else {
            //else return false do not let them log in
            return false;
        }
    }

}

//method to display vector information
void DisplayInfo(const std::vector<std::pair<std::string, int>>& clients) {
    //format printing
    std::cout << "Clients Name     Service Selected (1 = Brokerage, 2 = Retirement)" << std::endl;
    //loop through vector
    for (size_t i = 0; i < clients.size(); ++i) {
        //output formatting text and first, second pair values for each index of the vector
        std::cout << i+1 << ". " << clients[i].first << " selected option " << clients[i].second << std::endl;
    }
}

//prints menu choices
void menuChoices() {
    std::cout << "What would you like to do?" << std::endl;
    std::cout << "DISPLAY the client list (enter 1)" << std::endl;
    std::cout << "CHANGE a client's choice (enter 2)" << std::endl;
    std::cout << "EXIT the program.. (enter 3)" << std::endl;
}


int main()
{
    // output statement
    std::cout << "Created by Trenton Mendiola, Username = Trenton Password = 123" << std::endl;
    //create vector to store client names and choices
    std::vector<std::pair<std::string, int>> clients;
    //insert clients and options
    clients.push_back({ "Bob Jones", 1 });
    clients.push_back({ "Sarah Davis", 2 });
    clients.push_back({ "Amy Friendly", 1 });
    clients.push_back({ "Johnny Smith", 1 });
    clients.push_back({ "Carol Spears", 2 });
    //creats user vectore to store username and password
    std::vector<std::pair<std::string, std::string>> users;
    //insert user into vector
    users.push_back({ "Trenton", "123" });

    //username and password variables
    std::string userName, password;
    //menu choice variable
    int choice;

    //ask user for their username
    std::cout << "Enter your username:" << std::endl;

    //get username
    //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
    //check for invalid input variable (not string) and an empty string
    while (!(std::cin >> userName) || userName == " ") {
        //output error 
        std::cout << "Invalid Input!" << std::endl;
        //clear cin
        std::cin.clear();
        //ignore all of the input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    //ask user for password
    std::cout << "Enter your password:" << std::endl;

    //get password
    //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
    //check for invalid input variable (not string) and an empty string
    while (!(std::cin >> password) || password == " ") {
        //output error 
        std::cout << "Invalid Input!" << std::endl;
        //clear cin
        std::cin.clear();
        //ignore all of the input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }



    //bool value for authorize loop
    bool Authorized = false;
    //validate password
    //loop while authorized is not equal to true
    while (Authorized != true) {
        if (CheckUserPermissionAccess(users, userName, password) != 1) {
            std::cout << "Invalid Login. Please try again" << std::endl;
            //ask user for their username
            std::cout << "Enter your username:" << std::endl;

            //get username
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not string) and an empty string
            while (!(std::cin >> userName) || userName == " ") {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }

            //ask user for password
            std::cout << "Enter your password:" << std::endl;

            //get password
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not string) and an empty string
            while (!(std::cin >> password) || password == " ") {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
        }
        else {
            //they are authorized end loop 
            Authorized = true;
        }
    }


    //display menu choices
    menuChoices();

    //get user input for menu choice 
    //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
    //check for invalid input variable (not int) and check that the input is between 1 and 3
    while (!(std::cin >> choice) || choice > 3  || choice < 1 ) {
        //output error 
        std::cout << "Invalid Input!" << std::endl;
        //clear cin
        std::cin.clear();
        //ignore all of the input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    //bool to exit loop
    bool exit = false;
    //loop program while exit is not true
    while (exit != true) {
        //if the user enters 1 do menu choice 1 logic
        if (choice == 1)
        {
            //display confirmation for user input
            std::cout << "You chose 1" << std::endl;

            //call display info method
            DisplayInfo(clients);

            //display menu choices 
            menuChoices();

            //get users choice input
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not int) and check that the input is between 1 and 3
            while (!(std::cin >> choice) || choice > 3 || choice < 1) {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
        }
        //if the user enters 2 do menu choice 2 logic
        else if (choice == 2)
        {
            int clientSelect, optionSelect;

            //display confirmation for user input
            std::cout << "You chose 2" << std::endl;

            //ask what client's option they want to change
            std::cout << "Enter the number of the client that you wish to change" << std::endl;

            //get their input
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not int) and check that the input is between 1 and largest client select option
            while (!(std::cin >> clientSelect) || clientSelect > clients.size() || clientSelect < 1) {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }

            //reduce their input by 1 as vector index starts at 0 but displays as starting at 1 for user
            clientSelect -= 1;
            //aks what new choice they would like to set
            std::cout << "Please enter the client's new service choice (1 = Brokerage, 2 = Retirement" << std::endl;
   
            //get users choice input
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not int) and check that the input is between 1 and 2
            while (!(std::cin >> optionSelect) || optionSelect > 2 || optionSelect < 1) {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }

            //call method ChangeCustomerChoice, using clients vector and users input 
            ChangeCustomerChoice(clients, clientSelect, optionSelect);

            //display menu choices 
            menuChoices();

            //get users choice input
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not int) and check that the input is between 1 and 3
            while (!(std::cin >> choice) || choice > 3 || choice < 1) {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
        }
        else if (choice == 3) {

            //display confirmation for user input
            std::cout << "You chose 3" << std::endl;
            //change exit to true ending program
            exit = true;
        }
        //else user did not enter valid input
        else
        {
            std::cout << "Invalid Input" << std::endl;

            //display menu choices 
            menuChoices();

            //get users choice input
            //added input validation to eliminate buffer overflow, SQL injection and more vulnerabilities related to un validated input 
            //check for invalid input variable (not int) and check that the input is between 1 and 3
            while (!(std::cin >> choice) || choice > 3 || choice < 1) {
                //output error 
                std::cout << "Invalid Input!" << std::endl;
                //clear cin
                std::cin.clear();
                //ignore all of the input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }
        }

    }
    //added return 0 for proper ending of program
    return 0;
    
}

//references
//Creating and working with vector
//https://www.geeksforgeeks.org/how-to-create-vector-of-pairs-in-cpp/
//https://www.geeksforgeeks.org/pair-in-cpp-stl/
//https://www.geeksforgeeks.org/different-ways-to-print-elements-of-vector/
//
//Changing vector elements
//https://www.geeksforgeeks.org/change-an-element-by-index-in-vector-in-cpp/
// 
//input validation logic came from user Peter87 in the forum post "how to ensure an input is an integer?" on cplusplus.com
//and my 6-2 activity
//https://cplusplus.com/forum/beginner/283248/

